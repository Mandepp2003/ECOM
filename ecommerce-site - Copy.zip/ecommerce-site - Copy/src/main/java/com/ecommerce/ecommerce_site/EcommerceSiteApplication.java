package com.ecommerce.ecommerce_site;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceSiteApplication.class, args);
		System.out.println("this is starting point of app");
	}
	
	 public void run(String... args) throws Exception {
	
	}

}
