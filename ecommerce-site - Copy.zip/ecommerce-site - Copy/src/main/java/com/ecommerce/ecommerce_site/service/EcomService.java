package com.ecommerce.ecommerce_site.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.ecommerce_site.entity.Ecom;
import com.ecommerce.ecommerce_site.repository.EcomRepository;

@Service
public class EcomService {
	@Autowired
	private EcomRepository ecomRepository;

	public void saveEcom(Ecom ecom) {
		ecomRepository.save(ecom);
	}

	public Ecom loginEcom(String email, String password) {
		Ecom loginEcom = ecomRepository.loginEcom(email, password);
		return loginEcom;
	}

}
