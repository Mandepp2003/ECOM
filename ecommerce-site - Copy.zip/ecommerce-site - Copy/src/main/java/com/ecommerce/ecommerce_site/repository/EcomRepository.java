package com.ecommerce.ecommerce_site.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecommerce.ecommerce_site.entity.Ecom;

@Repository
public interface EcomRepository extends JpaRepository<Ecom, Long> {
	@Query("from Ecom where email =:e and password=:p")
	Ecom loginEcom(String e, String p);
}
