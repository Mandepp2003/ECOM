package com.ecommerce.ecommerce_site.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ecommerce.ecommerce_site.entity.Ecom;
import com.ecommerce.ecommerce_site.service.EcomService;

@Controller
public class EcomController {
	@Autowired
	private EcomService ecomService;

	@GetMapping("/eccom")
	public String showEmployeForm(Model model) {
		model.addAttribute("ecom", new Ecom());
		return "ecom";
	}

	@PostMapping("/saveEcom")
	public String saveEmployee(@ModelAttribute Ecom ecom) {
		ecomService.saveEcom(ecom);
		return "redirect:/submit";
	}

	@PostMapping("/loginIn")
	public String loginIn(@ModelAttribute Ecom ecom) {
		Ecom savedEcom = ecomService.loginEcom(ecom.getEmail(), ecom.getPassword());
		System.out.println(savedEcom);
		if (savedEcom != null) {
			return "redirect:/success";
		} else {
			return "redirect:/error1";
		}
	}

	@GetMapping("/Register")
	public String submit(Model model) {
		return "registrationsuccessful";
	}

	@GetMapping("/success")
	public String success(Model model) {
		return "success";
	}

	@GetMapping("/error1")
	public String error1(Model model) {
		return "error1";
	}

	@GetMapping("/home")
	public String showindex() {
		return "index";
	}

	// @GetMapping("/login")
	// public String showlogin() {
	// return "account";
	// }
	@GetMapping("/cart")
	public String showcart() {
		return "cart";
	}

	@GetMapping("/products")
	public String showproducts() {
		return "products";
	}
	@GetMapping("/product-details")
	public String showproduct(Model model) {
		return "product-details";
	}

	@GetMapping("/product2")
	public String showproduct2(Model model) {
		return "product2";
	}

	@GetMapping("/product3")
	public String showproduct3(Model model) {
		return "product3";
	}
}
